import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
export async function GET(request:Request){const url=new URL(request.url);const code=url.searchParams.get("code");const next=url.searchParams.get("next")||"/dashboard"; if(code){const s=await createSupabaseServerClient();await s.auth.exchangeCodeForSession(code);}return NextResponse.redirect(new URL(next,url.origin));}
